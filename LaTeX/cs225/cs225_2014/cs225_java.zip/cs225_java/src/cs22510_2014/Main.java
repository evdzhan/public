package cs22510_2014;

/**
 * Launcher Main class.
 * @author Evdzhan Mustafa enm3@aber.ac.uk
 *
 */
public class Main {

	public static void main(String[] args) {
		Controller.go();
	}
}
