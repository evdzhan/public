/* 
 * File:   main.c
 * Author: evdjoint
 *
 * Created on 22 March 2014, 00:59
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "gps_reader.h"
 



int main() {
    
    start();   
    return (EXIT_SUCCESS);
    
}

